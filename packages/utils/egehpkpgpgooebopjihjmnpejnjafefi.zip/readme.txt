Download Extension: https://www.ilovechrome.com/
About This Extension: https://www.ilovechrome.com/extension/egehpkpgpgooebopjihjmnpejnjafefi/
Install Extension: https://www.ilovechrome.com/install-crx.html