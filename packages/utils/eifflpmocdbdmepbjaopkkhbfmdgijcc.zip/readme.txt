Download Extension: https://www.ilovechrome.com/
About This Extension: https://www.ilovechrome.com/extension/eifflpmocdbdmepbjaopkkhbfmdgijcc/
Install Extension: https://www.ilovechrome.com/install-crx.html